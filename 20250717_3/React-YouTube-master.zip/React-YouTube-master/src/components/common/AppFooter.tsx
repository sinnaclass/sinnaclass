function AppFooter() {
    return <div>AppFooter</div>;
}

export { AppFooter };
