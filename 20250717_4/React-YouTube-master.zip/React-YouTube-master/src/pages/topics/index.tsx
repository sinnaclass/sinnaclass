function Topics() {
    return <div>Topics</div>;
}

export default Topics;
