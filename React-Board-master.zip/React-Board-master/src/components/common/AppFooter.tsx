function AppFooter() {
    return <div>AppFooter</div>;
}

export default AppFooter;
