import AppFooter from "@/components/common/AppFooter";
import AppHeader from "@/components/common/AppHeader";

function SignInPage() {
    return (
        <div>
            <AppHeader />
            <AppFooter />
        </div>
    );
}

export default SignInPage;
