import AppFooter from "@/components/common/AppFooter";
import AppHeader from "@/components/common/AppHeader";

function SignUpPage() {
    return (
        <div>
            <AppHeader />
            <AppFooter />
        </div>
    );
}

export default SignUpPage;
